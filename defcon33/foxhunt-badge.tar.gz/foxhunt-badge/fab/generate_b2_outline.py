"""
B2 Spirit silhouette outline generator for KiCad Edge.Cuts.

Generates a bilateral-symmetric flying-wing outline approximating the
Northrop B-2 Spirit. Output: KiCad 8 PCB graphic_line S-expressions
for the Edge.Cuts layer, plus a DXF for verification/import.

Coordinate system: KiCad mm, Y-down. Origin at top-center of badge.
Total width tunable via SPAN_MM. Defaults sized for a 100mm-wide badge.
"""

import math
from pathlib import Path

# ---- Tunables ----
SPAN_MM       = 100.0     # full wingspan
CHORD_MM      = 55.0      # nose-to-tail center length
NOSE_RADIUS   = 4.0       # radius of nose tip blend
TRAILING_W    = 0.80      # trailing-edge "W" depth as fraction of CHORD
WINGTIP_TAPER = 0.92      # wingtip Y position as fraction of CHORD

# B-2 has a distinctive sawtooth trailing edge (4 peaks, 4 valleys symmetric).
# We define the half-outline as a list of (x, y) points from nose forward,
# along the leading edge to wingtip, then back along the trailing edge to centerline.
# Mirror across X=0 to get the full silhouette.

def half_outline():
    """Return list of (x, y) for RIGHT half, traversed clockwise from nose.

    Trailing edge: 3 aft-pointing triangles total across the bird (one center,
    two outboard).  Right-half pattern, going from wingtip toward centerline:

        wingtip (slight forward notch)
          -> right outboard PEAK (1st triangle, ~55% half-span)
          -> inner valley (forward notch, ~30% half-span)
          -> centerline PEAK (the rear-most central triangle)

    After mirroring, the full outline has: left outboard peak,
    center peak, right outboard peak = 3 aft-pointing triangles total.
    """
    pts = []
    half = SPAN_MM / 2.0

    # Nose (centerline, top)
    pts.append((0.0, 0.0))

    # Leading edge - swept back, slightly curved
    for i in range(1, 9):
        t = i / 8.0
        x = half * t ** 0.95
        y = CHORD_MM * 0.58 * t ** 1.05
        pts.append((x, y))

    # Wingtip (relatively narrow, slightly forward of trailing edge peaks)
    pts.append((half, CHORD_MM * 0.66))

    # Trailing edge geometry
    peak_y          = CHORD_MM * 1.00      # rear-most extent
    outboard_y      = CHORD_MM * 1.00      # outboard peaks
    valley_y        = CHORD_MM * 0.78      # forward notches between peaks
    wingtip_notch_y = CHORD_MM * 0.72      # small notch right at wingtip

    # Small forward notch immediately inboard of wingtip
    pts.append((half * 0.85, wingtip_notch_y))

    # Right outboard PEAK (1st aft-pointing triangle)
    pts.append((half * 0.58, outboard_y))

    # Inner valley between outboard peak and center peak
    pts.append((half * 0.30, valley_y))

    # Centerline PEAK (the central, rear-most aft-pointing triangle)
    pts.append((0.0, peak_y))

    return pts

def full_outline():
    right = half_outline()
    # Mirror to get left side; reverse so polygon is continuous
    left = [(-x, y) for (x, y) in reversed(right[1:-1])]  # exclude shared centerline pts
    return right + left + [right[0]]  # close polygon

def to_kicad_lines(points, layer="Edge.Cuts", width=0.15):
    """Emit KiCad 8 (gr_line ...) S-expressions for a closed polyline."""
    lines = []
    for i in range(len(points) - 1):
        x1, y1 = points[i]
        x2, y2 = points[i + 1]
        lines.append(
            f'  (gr_line (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) '
            f'(stroke (width {width}) (type solid)) (layer "{layer}") '
            f'(uuid "{generate_uuid(i)}"))'
        )
    return "\n".join(lines)

def to_dxf(points, path):
    """Minimal DXF R12 with closed polyline. Importable as Edge.Cuts."""
    out = []
    out.append("0\nSECTION\n2\nHEADER\n0\nENDSEC")
    out.append("0\nSECTION\n2\nENTITIES")
    out.append("0\nPOLYLINE\n8\n0\n66\n1\n70\n1")
    for x, y in points:
        out.append(f"0\nVERTEX\n8\n0\n10\n{x:.4f}\n20\n{-y:.4f}\n30\n0.0")  # flip Y for CAD convention
    out.append("0\nSEQEND")
    out.append("0\nENDSEC\n0\nEOF")
    Path(path).write_text("\n".join(out))

def generate_uuid(seed):
    import hashlib
    h = hashlib.md5(f"b2-edge-{seed}".encode()).hexdigest()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"

if __name__ == "__main__":
    pts = full_outline()
    print(f"Generated {len(pts)} outline points")
    print(f"Bounding box: X=[{min(p[0] for p in pts):.2f}, {max(p[0] for p in pts):.2f}] "
          f"Y=[{min(p[1] for p in pts):.2f}, {max(p[1] for p in pts):.2f}]")
    # Emit KiCad fragment
    Path("b2_edge_cuts.kicad_fragment").write_text(to_kicad_lines(pts))
    # Emit DXF
    to_dxf(pts, "b2_outline.dxf")
    print("Wrote b2_edge_cuts.kicad_fragment and b2_outline.dxf")
